#include <stdio.h>

int main(){
    char str1[500], str2[500];
    printf("Enter the first string: ");
    scanf("%s",str1);
    getchar();
    
        printf("Enter the secound string: ");
        
    scanf("%s",str2);
    getchar();
    printf("%s",str1);
    printf(" %s",str2);
}