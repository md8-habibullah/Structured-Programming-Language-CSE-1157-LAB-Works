#include <stdio.h>

void print_message() {
    printf("This is a function\n");
}

int main() {
    print_message();
    return 0;
}